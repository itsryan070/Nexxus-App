window.onload = start;

function start(){
	controller = new controller()
}