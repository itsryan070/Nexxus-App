class model{
	constructor(controller,view){
		//vrijwilliger
		var model = this;
		this.aangeboden = [];
		this.selected = 0;
		this.Creeerinfo();
		this.c = controller;
		this.view = view;
	}

	//vrijwilliger
	Gettitle(){
		var title = [];
		for(var x=1; x < this.aangeboden.length; x++){
			title.push("<td>"+ this.aangeboden[x][2]+"</td> <td> "+ this.aangeboden[x][3]+'</td><td> '+this.aangeboden[x][0] + " </td>")
		}
		return title;
	}
	Getinfoselect(selected){
		this.selected = selected;
		var stad = this.aangeboden[selected][0];
		var straat = this.aangeboden[selected][1];
		var datum = this.aangeboden[selected][2];
		var wat = this.aangeboden[selected][3];
		var tijd = this.aangeboden[selected][4];
		var contact = this.aangeboden[selected][5];
		var tel = this.aangeboden[selected][6];
				
		return '<tbody id="info"><tr>  <td id="stad" ><b class="ui-table-cell-label" style="width: 30vw;"> Stad: </b></td><td style="max-width:40vw"> ' + stad + '</td></tr><tr>  <td id="straat"><b class="ui-table-cell-label"  style="width: 30vw;"> Straat: </b></td><td style="max-width:40vw"> '+ straat +'</td></tr><tr> <td id="datum"><b class="ui-table-cell-label" style="width: 30vw;"> Datum: </b></td><td style="max-width:40vw"> '+ datum +'</td></tr><tr> <td id="wat"><b class="ui-table-cell-label"  style="width: 30vw;"> Hoeveelheid: </b> </td><td style="max-width:40vw">'+wat +'</td></tr><tr><td id="tijd"><b class="ui-table-cell-label"  style="width: 30vw;"> Tijd: </b></td><td style="max-width:40vw">'+ tijd +'</td></tr><tr><td id="contact"><b class="ui-table-cell-label"  style="width: 30vw;"> Contact: </b></td><td style="max-width:40vw">'+ contact +' </td></tr><tr><td id="tel"><b class="ui-table-cell-label" style="width: 30vw;"> Telefoon: </b></td><td style="max-width:40vw">'+ tel +' </td></tr></tbody>'; 
	}
	Geaccepteerd(){
		this.aangeboden = this.aangeboden.slice(0,this.selected); // make copy
   		this.aangeboden.splice(this.selected);
   		this.view.ViewTitle(this.Gettitle());
   		this.c.Setinfoselected(this.selected);
	}
	GetAmount(){
		return this.aangeboden[this.selected][3];
	}
	


	Creeerinfo(){
		for(var x = 1; x < 11; x++){
			this.aangeboden[x] = [x];
			for(var y = 0; y < 6; y++){
				this.aangeboden[x][y] = 0;
			}
		}
		this.aangeboden[1][0] = ("Den Haag");
		this.aangeboden[1][1] = ("Breedstraat 128");
		this.aangeboden[1][2] = ("1-11-18");
		this.aangeboden[1][3] = ("1 fiets");
		this.aangeboden[1][4] = ("14:00 t/m 17:00");
		this.aangeboden[1][5] = ("Ben");
		this.aangeboden[1][6] = ("0612345678");

		this.aangeboden[2][0] = ("Groningen");
		this.aangeboden[2][1] = ("Pietjan 538");
		this.aangeboden[2][2] = ("1-31-18");
		this.aangeboden[2][3] = ("8 fietsen");
		this.aangeboden[2][4] = ("14:00 t/m 17:00");
		this.aangeboden[2][5] = ("Jan");
		this.aangeboden[2][6] = ("0612345678");

		this.aangeboden[3][0] = ("Rotterdam");
		this.aangeboden[3][1] = ("Jansenlaan 263");
		this.aangeboden[3][2] = ("2-11-18");
		this.aangeboden[3][3] = ("4 fietsen");
		this.aangeboden[3][4] = ("10:00 t/m 12:00");
		this.aangeboden[3][5] = ("Pieter");
		this.aangeboden[3][6] = ("0612345678");

		this.aangeboden[4][0] = ("Amsterdam");
		this.aangeboden[4][1] = ("kroonstraat 321");
		this.aangeboden[4][2] = ("1-11-18");
		this.aangeboden[4][3] = ("6 fietsen");
		this.aangeboden[4][4] = ("10:00 t/m 17:00");
		this.aangeboden[4][5] = ("Timo");
		this.aangeboden[4][6] = ("0612345678");

		this.aangeboden[5][0] = ("Almere");
		this.aangeboden[5][1] = ("Bakkerstaat 128");
		this.aangeboden[5][2] = ("1-11-18");
		this.aangeboden[5][3] = ("4 fietsen");
		this.aangeboden[5][4] = ("12:00 t/m 15:00");
		this.aangeboden[5][5] = ("Ronald");
		this.aangeboden[5][6] = ("0612345678");

		this.aangeboden[6][0] = ("Utrecht");
		this.aangeboden[6][1] = ("wolthuize 128");
		this.aangeboden[6][2] = ("1-11-18");
		this.aangeboden[6][3] = ("4 fietsen");
		this.aangeboden[6][4] = ("12:00 t/m 15:00");
		this.aangeboden[6][5] = ("Ronald");
		this.aangeboden[6][6] = ("0612345678");

		this.aangeboden[7][0] = ("Enschede");
		this.aangeboden[7][1] = ("melisstraat 128");
		this.aangeboden[7][2] = ("1-11-18");
		this.aangeboden[7][3] = ("4 fietsen");
		this.aangeboden[7][4] = ("12:00 t/m 15:00");
		this.aangeboden[7][5] = ("Ronald");
		this.aangeboden[7][6] = ("0612345678");

		this.aangeboden[8][0] = ("Maastricht");
		this.aangeboden[8][1] = ("Bakkerstaat 128");
		this.aangeboden[8][2] = ("1-11-18");
		this.aangeboden[8][3] = ("4 fietsen");
		this.aangeboden[8][4] = ("12:00 t/m 15:00");
		this.aangeboden[8][5] = ("Ronald");
		this.aangeboden[8][6] = ("0612345678");

		this.aangeboden[9][0] = ("Zoetemeer");
		this.aangeboden[9][1] = ("cadmiumgeel 128");
		this.aangeboden[9][2] = ("1-11-18");
		this.aangeboden[9][3] = ("4 fietsen");
		this.aangeboden[9][4] = ("12:00 t/m 15:00");
		this.aangeboden[9][5] = ("Ronald");
		this.aangeboden[9][6] = ("0612345678");

		this.aangeboden[10][0] = ("Berg op Zoom");
		this.aangeboden[10][1] = ("Bakkerstaat 128");
		this.aangeboden[10][2] = ("1-11-18");
		this.aangeboden[10][3] = ("4 fietsen");
		this.aangeboden[10][4] = ("12:00 t/m 15:00");
		this.aangeboden[10][5] = ("Ronald");
		this.aangeboden[10][6] = ("0612345678");
	}

}