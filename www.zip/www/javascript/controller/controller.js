class controller{
	constructor(){
		var controller = this;
		this.view = new view(this);
		this.model = new model(this,this.view);
		this.view.ViewTitle(this.model.Gettitle());
	}

	//algemeen
	GetLogin(){
		var naam = $("input[name='txt-username']").val();
		if(naam=="v"){
			window.open('v/html/Aangeboden.html', '_self');
		}else if(naam == "m"){
			window.open('m/html/start.html', '_self');
		}
	}	

	//vrijwilliger 
	Setinfoselected(num){
		this.view.ViewInfoSelected(this.model.Getinfoselect(num));
		this.amount = this.model.GetAmount();
	}
	Geaccepteerd(){
		this.model.Geaccepteerd();
	}
	Geweigerd(){

	}
	ViewFoto(tf){
		if(tf == true){
			this.view.ViewFoto();
		}else{
			this.view.ViewVraag();
		}
	}
	CloseInfo(tf){
		this.view.CloseInfo(tf);
	}
	CloseInfoSelected(){
		this.view.CloseInfoSelected()
	}

	//monteur
	OpenZoek(){
		this.view.OpenZoek()
	}
	SluitZoek(){
		this.view.CloseZoek();
	}
	showProduct(id){
		this.view.showProduct();
	}
}	