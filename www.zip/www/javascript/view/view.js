class view{

	//vrijwilliger
	constructor(controller){
		var view = this;
		var c =  controller;
		$( '.visability').hide();
		$( '.visability1').hide();
		this.switch = false;
	}
	ViewInfoSelected(text){
		$("#info").replaceWith(text);
		$( '.visability' ).show();	
		$('.ui-resize').animate({height:'30vh'});
	}	
	CloseInfoSelected(){
		console.log("test")
		if(true == this.tf){
			$( '.visability' ).hide();	
			$( '.visability1' ).hide();
			$('.ui-resize').animate({height:'70vh'});
			this.switch = false
		}else if(false == this.switch){
			window.open('Taken.html', '_self');
		}
	}
	ViewTitle(titles){
		$("#title tr").remove();
		$("#title td").remove();
		$("#title").append("<td><b>Datum</b> </td><td><b>Hoeveelheid</b> </td><td><b>Stad</b> </td>");
		for(var x=0; x < titles.length; x++){
			$("#title").append("<tr onclick=" + "controller.Setinfoselected('"+(x+1)+"')" + " data-priority='1' id='title"+x+"'>" + titles[x] +  "</tr>");
		}	
	}
	CloseInfo(){
		$( '.visability' ).hide();
		$('.ui-resize').animate({height:'70vh'});
		$('.ui-resize').show()
	}
	ViewFoto(){
		$( '.visability' ).show();	
		$('.ui-resize').animate({height:'0'});
		this.switch = true;
	}
	ViewVraag(){
		$( '.visability1' ).show();	
		$('.ui-resize').animate({height:'0'});
		this.switch = true;
	}

	//monteur
	OpenZoek(){
		$("#search").hide();
		$( '#searchcontainer').show();
		$('#searchcontainer').animate({width:'50vw'});
	}
	CloseZoek(){
		$("#search").show();
		$('#searchcontainer').animate({width:'0vw'});
		$( '#searchcontainer').hide();
	}
	showProduct(){
		$( '.visability' ).show();	
		$('.ui-resize').animate({height:'0h'});
		$('.ui-resize').hide();
	}
}